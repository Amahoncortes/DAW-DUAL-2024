package MasEjercicios.k_Biblioteca;

public interface Prestable {
    void prestar();

    void devolver();

    boolean prestado();

}