package MasEjercicios.l_CollectionPila;

public interface CollectionInterface {
    boolean isEmpty();
    Object get();
    Object first();
    boolean add(Object objeto);
}
