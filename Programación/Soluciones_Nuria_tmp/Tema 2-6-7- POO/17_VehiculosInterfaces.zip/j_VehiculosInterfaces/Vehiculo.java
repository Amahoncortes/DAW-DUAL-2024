package MasEjercicios.j_VehiculosInterfaces;

public interface Vehiculo {
    int VMAX = 120;

    String frenar(int vel);
    String acelerar(int vel);
}
