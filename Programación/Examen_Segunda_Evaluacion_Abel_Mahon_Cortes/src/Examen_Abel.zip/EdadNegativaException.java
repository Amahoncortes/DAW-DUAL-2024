public class EdadNegativaException extends Exception {

    public EdadNegativaException() {

    }

    public EdadNegativaException(String mensaje) {
        super(mensaje);
    }
}
