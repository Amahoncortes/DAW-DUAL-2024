import java.util.ArrayList;

public interface ClinicaInterface {
    void calcularCoste(ArrayList<Veterinario>veterinarios);
}
