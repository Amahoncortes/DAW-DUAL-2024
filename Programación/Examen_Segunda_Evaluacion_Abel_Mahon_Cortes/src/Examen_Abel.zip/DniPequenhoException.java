public class DniPequenhoException extends Exception {
    public DniPequenhoException() {

    }

    public DniPequenhoException(String mensaje) {
        super(mensaje);
    }
}
