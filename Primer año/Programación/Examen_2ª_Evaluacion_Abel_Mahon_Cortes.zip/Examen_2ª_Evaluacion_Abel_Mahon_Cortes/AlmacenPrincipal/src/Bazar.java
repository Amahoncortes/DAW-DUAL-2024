public class Bazar extends Producto{
    private String tipo;

    //Constructor por defecto
    public Bazar() {
        super();
        this.tipo = "";
    }


    //Constructor parametrizado
    public Bazar(double precio, String nombre, String categoria, String tipo) {
        super(precio, nombre, categoria);
        this.tipo = tipo;
    }

    //GETTERS Y SETTERS

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }


}
