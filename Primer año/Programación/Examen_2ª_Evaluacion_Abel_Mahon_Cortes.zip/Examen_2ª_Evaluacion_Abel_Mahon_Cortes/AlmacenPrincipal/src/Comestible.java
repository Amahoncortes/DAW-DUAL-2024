import java.time.LocalDate;
import java.util.Date;


public class Comestible  extends Producto{
    private Date fechaCaducidad;
    //Constructor por defecto

    public Comestible() {
        super();
        this.fechaCaducidad = new Date();
    }

    public Comestible(double precio, String nombre, String categoria,  Date fechaCaducidad) {
        super(precio, nombre, categoria);
        this.fechaCaducidad = fechaCaducidad;
    }

    //GETTERS Y SETTERS

    public Date getFechaCaducidad() {
        return fechaCaducidad;
    }

    public void setFechaCaducidad(Date fechaCaducidad) {
        this.fechaCaducidad = fechaCaducidad;
    }


}
