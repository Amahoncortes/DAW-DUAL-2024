import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class AlmacenPrincipal {
    //Crea una lista de productos y una de comerciales
    //Productos:
    static ArrayList<Producto> productos = new ArrayList<>();
    //Comerciales
    static ArrayList<Comercial> comerciales = new ArrayList<>();

    public static void main(String[] args) throws ParseException {


        Scanner sc = new Scanner(System.in);
        int opcion;
        System.out.println("Introduzca una opcion");

        do {
            menu();
            opcion = sc.nextInt();
            switch (opcion) {
                case 1:
                    //Damos de alta los productos
                    productos.add(altaProducto());

                case 2:
                    //
            }
        }
        while (opcion != 7);
    }

    private static void menu() {
        //Encabezado
        System.out.println("--------------------");
        System.out.println("Menú de Almacen");
        System.out.println("--------------------");
        System.out.println("Seleccione lo que desea realizar:");
        System.out.println("1: Alta productos");
        System.out.println("2: Alta comerciales");
        System.out.println("3: Eliminar productos de Limpieza");
        System.out.println("4: Mostrar especialidades de los comerciales");
        System.out.println("5: Coste medio de comestibles");
        System.out.println("6: Productos de caducidad próxima");
        System.out.println("7: Salir");
    }

    private static Producto altaProducto() throws ParseException {
        Scanner sc = new Scanner(System.in);
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        double precio;
        String nombre, categoria;
        Producto p;

        System.out.println("-------- Alta productos ---------");

        System.out.println("Introduzca nombre");
        nombre = sc.nextLine();

        sc = new Scanner(System.in);
        System.out.println("Introduzca precio");
        precio = sc.nextDouble();

        sc = new Scanner(System.in);
        System.out.println("Introduzca categoría (Comestible/Bazar)");
        categoria = sc.nextLine();


        if (Objects.equals(categoria, "Comestible")) {
            String fechaSolicitada;
            Date fechaCaducidad;
            System.out.println("introduzca una fecha de caducidad(Formato dd/MM/yyyy)");
            fechaSolicitada = sc.nextLine();
            fechaCaducidad = sdf.parse(fechaSolicitada);
            p = new Comestible(precio, nombre, categoria, fechaCaducidad);

        } else if (Objects.equals(categoria, "Bazar")) {
            String tipo;
            System.out.println("Introduce un tipo");
            tipo = sc.nextLine();
            p = new Bazar(precio, nombre, categoria, tipo);
        } else {
            throw new Error("Error. Categoría incorrecta. Introduzca categoría (Comestible/Bazar)");
        }
        System.out.println(p);
        return p;
    }

    private static Comercial altaComercial() {
        Scanner sc = new Scanner(System.in);
        Comercial c;
        int edad;
        String nombre, apellidos, zona;
        System.out.println("-------- Alta comerciales ---------");

        System.out.println("Introduzca nombre");
        nombre = sc.nextLine();

        System.out.println("Introduzca apellidos");
        apellidos = sc.nextLine();

        System.out.println("Introduzca zona");
        zona = sc.nextLine();

        System.out.println("Introduzca edad");
        edad = sc.nextInt();

        return new Comercial(nombre, apellidos, edad, zona, crearRegistroComercial());
    }

    // En el siguiente método, cambiar tipo de dato de retorno al tipo de colección elegida para el registro de los comerciales
    // Los elementos en el registro pueden introducirse manualmente, sin necesidad de solicitarlos por teclado.
    private static HashMap<Integer, Comercial> crearRegistroComercial() {
        HashMap<Integer, Comercial> comerciales = new HashMap<>();
        comerciales.put(1, new Comercial());
        comerciales.put(2, new Comercial());
        comerciales.put(3, new Comercial());
        return comerciales;
    }


    private static void eliminarProductosLimpieza() {
    }

    private static void especialidadComerciales() {
    }

    private static void costeProductos() {
    }

    private static void productosCaducidadProxima() {
    }
}
