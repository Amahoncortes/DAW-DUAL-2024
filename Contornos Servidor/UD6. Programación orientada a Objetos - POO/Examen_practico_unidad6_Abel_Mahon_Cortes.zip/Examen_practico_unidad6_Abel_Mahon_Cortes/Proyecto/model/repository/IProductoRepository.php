<?php

/**
 * Ejercicio 3.Crea la interfaz IProductoRepository que extienda de IBaseRepository
 */
interface IProductoRepository extends IBaseRepository
{
    
}
