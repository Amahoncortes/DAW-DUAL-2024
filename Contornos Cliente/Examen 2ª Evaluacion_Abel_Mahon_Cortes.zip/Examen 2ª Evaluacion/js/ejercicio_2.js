window.addEventListener("DOMContentLoaded", () => {

    //asignacion
    const cantidad = document.getElementsByClassName("cantidad");

    const divUvas = document.getElementById("uvas");

    const divNaranjas = document.getElementById("naranjas");

    const divFresas = document.getElementById("fresa");

    const divSandias = document.getElementById("sandia");

    const btnComprar = document.getElementsByClassName("botonComprar");

    const btnVaciar = document.getElementById("vaciar");

    //escuchadores
    btnComprar.addEventListener("click", () => {
        let precio = cantidad.value;
        
    })



})