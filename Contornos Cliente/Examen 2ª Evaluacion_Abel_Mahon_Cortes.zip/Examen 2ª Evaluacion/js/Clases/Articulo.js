//Crear 4 objetos de tipo artículo con los siguientes campos: nombre, precio. Almacenarlo en un array
