// Obtenermos la url acutal del navegador
let obtenerUrlActual = window.location;
console.log("ola!" + obtenerUrlActual);